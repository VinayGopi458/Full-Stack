const mysql = require('mysql2/promise');
require('dotenv').config();

async function debug() {
    try {
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST || 'localhost',
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASSWORD || '',
            database: process.env.DB_NAME || 'job_portal_db'
        });
        
        console.log("Connected to DB...");
        
        try {
            const [rows] = await connection.query("SHOW TABLES LIKE 'users';");
            if (rows.length === 0) {
                console.log("ERROR: The 'users' table DOES NOT EXIST!");
            } else {
                console.log("The 'users' table exists!");
                const [columns] = await connection.query("SHOW COLUMNS FROM users;");
                console.log("Columns:", columns.map(c => c.Field).join(', '));
            }
        } catch(e) {
            console.log("Failed to query tables:", e.message);
        }

        connection.end();
        process.exit(0);
    } catch (error) {
        console.error('Connection failed:', error.message);
        process.exit(1);
    }
}

debug();
