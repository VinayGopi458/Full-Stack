const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const commonPasswords = ['', 'root', 'admin', 'password', '1234', '12345678', 'project123'];
const dbName = 'job_portal_db';

async function fix() {
    console.log("🚀 Starting Automated Connection Fix...");
    
    let workingPassword = null;
    let connection = null;

    for (const pwd of commonPasswords) {
        try {
            console.log(`Checking password: "${pwd}"...`);
            connection = await mysql.createConnection({
                host: 'localhost',
                user: 'root',
                password: pwd,
                multipleStatements: true
            });
            workingPassword = pwd;
            console.log(`✅ SUCCESS! Found working password: "${pwd}"`);
            break;
        } catch (e) {
            // Continue
        }
    }

    if (workingPassword !== null) {
        try {
            // Update .env
            let envContent = fs.readFileSync('.env', 'utf8');
            envContent = envContent.replace(/DB_PASSWORD=.*/, `DB_PASSWORD=${workingPassword}`);
            fs.writeFileSync('.env', envContent);
            console.log("📝 Updated .env with correct password.");

            // Run Schema
            console.log("📜 Executing schema.sql...");
            const sql = fs.readFileSync('schema.sql', 'utf8');
            await connection.query(sql);
            console.log("✅ Database and tables initialized.");

            await connection.end();
            console.log("\n✨ YOUR PROJECT IS NOW CONNECTED AND COMPLETE!");
            console.log("Run 'npm start' or 'node server.js' to see the website.");
            process.exit(0);
        } catch (error) {
            console.error("❌ Error during final setup:", error.message);
            process.exit(1);
        }
    } else {
        console.error("\n❌ Could not find the correct password automatically.");
        console.error("Please ensure your MySQL server is running and you have the right credentials.");
        process.exit(1);
    }
}

fix();
