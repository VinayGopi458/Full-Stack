const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

router.post('/register', userController.register);
router.post('/login', userController.login);
router.get('/:id', userController.getProfile);
router.get('/:id/applications', userController.getUserApplications);

module.exports = router;
