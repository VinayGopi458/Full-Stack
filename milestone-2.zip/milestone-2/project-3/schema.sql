CREATE DATABASE IF NOT EXISTS job_portal_db;
USE job_portal_db;

CREATE TABLE IF NOT EXISTS jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    company VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    salary VARCHAR(100),
    experience_level ENUM('Entry', 'Mid', 'Advance') DEFAULT 'Entry',
    description TEXT,
    requirements TEXT,
    posted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    job_id INT NOT NULL,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    UNIQUE KEY unique_application (user_id, job_id)
);

-- Insert dummy data
INSERT INTO jobs (title, company, location, salary, experience_level, description, requirements) VALUES 
('Frontend Intern', 'Web Studio', 'Remote', '₹15,000 - ₹25,000 / month', 'Entry', 'Join our team as a frontend intern to learn modern web technologies.', 'Basic knowledge of HTML, CSS, JavaScript'),
('Junior Software Engineer', 'Tech Start', 'Bangalore, IN', '₹5,00,000 - ₹8,00,000 / year', 'Entry', 'Looking for an enthusiastic fresher to kickstart their career.', 'B.Tech in CS or related field, understanding of full-stack concepts.'),
('React Developer (Mid-level)', 'Creative Apps', 'Hyderabad, IN', '₹12,00,000 - ₹18,00,000 / year', 'Mid', 'Build scalable user interfaces with React and Redux.', '2-3 years hands-on experience in React.js'),
('Senior Full Stack Developer', 'Global Tech', 'Pune, IN', '₹25,00,000 - ₹40,00,000 / year', 'Advance', 'Lead our engineering team in building complex enterprise systems.', '5-10 years experience, Node.js, React, architectural patterns.');
