require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const jobRoutes = require('./routes/jobRoutes');
const userRoutes = require('./routes/userRoutes');

const db = require('./config/db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const staticPath = path.join(__dirname, 'public');
const uploadsPath = path.join(__dirname, 'public/uploads');

app.use(express.static(staticPath));
app.use('/uploads', express.static(uploadsPath));

app.use('/api/jobs', jobRoutes);
app.use('/api/users', userRoutes);

// Error Handling Middleware
app.use((err, req, res, next) => {
    console.error("GLOBAL ERROR:", err);
    res.status(500).json({ message: "Internal Server Error: " + err.message });
});

app.listen(PORT, async () => {
    console.log(`Serving static files from: ${staticPath}`);
    console.log(`Server running on http://localhost:${PORT}`);
    
    try {
        // Test database connection
        await db.query('SELECT 1');
        console.log('Database connected successfully');
    } catch (error) {
        console.error('❌ Database connection failed:', error.message);
    }
});
