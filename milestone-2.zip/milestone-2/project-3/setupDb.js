const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

async function setupDb() {
    console.log("Connecting to the database server...");
    try {
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST || 'localhost',
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASSWORD || '',
            multipleStatements: true,
            connectTimeout: 10000 // 10s timeout
        });

        console.log("Connected successfully! Reading schema.sql...");
        
        const schemaPath = path.join(__dirname, 'schema.sql');
        const sql = fs.readFileSync(schemaPath, 'utf8');
        
        console.log("Executing schema.sql to create database and tables...");
        await connection.query(sql);
        
        console.log("✅ Database initialized and seed data inserted successfully!");
        
        // Give it a quick test
        const [rows] = await connection.query("SELECT * FROM job_portal_db.jobs");
        console.log(`Found ${rows.length} jobs in the database.`);
        
        await connection.end();
    } catch (error) {
        console.error("❌ Failed to set up the database.");
        if (error.code === 'ER_ACCESS_DENIED_ERROR') {
            console.error("Error: Access denied. Pleas verify DB_USER and DB_PASSWORD in your .env file.");
        } else if (error.code === 'ECONNREFUSED') {
            console.error("Error: Connection refused. Is your MySQL server (XAMPP/MySQL) running on localhost?");
        } else {
            console.error(`Error: ${error.message}`);
        }
    }
}

setupDb();
