document.addEventListener('DOMContentLoaded', () => {
    // Check Auth State for navigation links across all pages
    const userStr = localStorage.getItem('user');
    const user = userStr ? JSON.parse(userStr) : null;
    
    // Update navigation based on auth state (except when it might conflict with page specific hardcoded navs, 
    // but here we just globally set the nav content if we want a dynamic nav, or just handle logout)
    
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            localStorage.removeItem('user');
            window.location.href = 'login.html';
        });
    }

    // Login Form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorDiv = document.getElementById('auth-error');
            errorDiv.textContent = '';

            try {
                const response = await fetch('/api/users/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });

                const data = await response.json();
                
                if (response.ok) {
                    localStorage.setItem('user', JSON.stringify({ id: data.id, name: data.name, email: data.email }));
                    window.location.href = 'index.html';
                } else {
                    errorDiv.textContent = data.message || 'Login failed';
                }
            } catch (error) {
                errorDiv.textContent = 'Server error. Please try again later.';
            }
        });
    }

    // Register Form
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorDiv = document.getElementById('auth-error');
            errorDiv.textContent = '';

            try {
                const response = await fetch('/api/users/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name, email, password })
                });

                const data = await response.json();
                
                if (response.ok) {
                    // Auto login after simple register
                    localStorage.setItem('user', JSON.stringify({ id: data.id, name: data.name, email: data.email }));
                    window.location.href = 'index.html';
                } else {
                    errorDiv.textContent = data.message || 'Registration failed';
                }
            } catch (error) {
                errorDiv.textContent = 'Server error. Please try again later.';
            }
        });
    }
});
