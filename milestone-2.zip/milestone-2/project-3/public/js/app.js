// Global functions for inline Event Handlers
window.fetchJobs = async (level = '', search = '') => {
    const jobListings = document.getElementById('job-listings');
    try {
        let url = '/api/jobs?';
        if (level) url += `level=${level}&`;
        if (search) url += `search=${encodeURIComponent(search)}&`;
        
        const response = await fetch(url);
        if (!response.ok) throw new Error('Failed to fetch jobs');
        
        const jobs = await response.json();
        renderJobs(jobs);
    } catch (error) {
        console.error('Error:', error);
        jobListings.innerHTML = '<p class="text-center" style="grid-column: 1/-1; color: #ef4444;">Unable to load jobs. Please check if the server is running.</p>';
    }
};

const renderJobs = (jobs) => {
    const jobListings = document.getElementById('job-listings');
    jobListings.innerHTML = '';
    
    if (jobs.length === 0) {
        jobListings.innerHTML = '<p class="text-center" style="grid-column: 1/-1;">No jobs found matching your criteria.</p>';
        return;
    }

    jobs.forEach((job, index) => {
        const delay = index * 0.05; // Staggered animation
        const jobCard = document.createElement('div');
        jobCard.className = 'job-card glassmorphism';
        jobCard.style.animation = `fadeUp 0.6s cubic-bezier(0.23, 1, 0.32, 1) forwards ${delay}s`;
        jobCard.style.opacity = '0';
        
        jobCard.innerHTML = `
            <h4 class="job-title">${job.title}</h4>
            <div class="job-company">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 8px;"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
                ${job.company}
            </div>
            <div class="job-meta">
                <span>📍 ${job.location}</span>
                <span>💰 ${job.salary || 'Not specified'}</span>
                <span>🎓 ${job.experience_level || 'Any'}</span>
            </div>
            <p class="job-desc">${job.description}</p>
            <div class="job-reqs text-muted" style="margin-top:15px; font-size: 0.85rem; padding-top: 15px; border-top: 1px solid var(--border-color);">
                <strong>Requirements:</strong> ${job.requirements || 'N/A'}
            </div>
            <button class="btn-primary apply-btn" style="margin-top: 20px; width: 100%;" onclick="applyJob(${job.id}, this)">Apply Now</button>
        `;
        jobListings.appendChild(jobCard);
    });
};

window.filterJobs = (level) => {
    const searchInput = document.getElementById('search-input');
    const jobListings = document.getElementById('job-listings');
    
    // Update active button styling
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.style.background = 'rgba(255,255,255,0.1)';
        btn.classList.remove('active');
    });
    
    const currentBtn = event.currentTarget;
    currentBtn.style.background = 'var(--primary)';
    currentBtn.classList.add('active');
    
    jobListings.innerHTML = '<div class="loader" id="loader"></div>';
    window.fetchJobs(level, searchInput.value);
};

window.applyJob = (jobId, btnElement) => {
    const userStr = localStorage.getItem('user');
    if (!userStr) {
        window.location.href = 'register.html';
        return;
    }
    
    const user = JSON.parse(userStr);
    const modal = document.getElementById('apply-modal');
    const modalJobId = document.getElementById('modal-job-id');
    const modalJobTitle = document.getElementById('modal-job-title');
    const applyName = document.getElementById('apply-name');
    
    // Fill modal info
    modalJobId.value = jobId;
    const jobTitle = btnElement.closest('.job-card').querySelector('.job-title').innerText;
    modalJobTitle.innerText = `Apply for ${jobTitle}`;
    applyName.value = user.name;
    
    // Show modal
    modal.style.display = 'flex';
};

document.addEventListener('DOMContentLoaded', () => {
    const searchBtn = document.getElementById('search-btn');
    const searchInput = document.getElementById('search-input');
    const applyModal = document.getElementById('apply-modal');
    const closeModalBtn = document.getElementById('close-modal');
    const applyForm = document.getElementById('apply-form');

    // Initial Load
    window.fetchJobs();

    // Modal Closing Logic
    if (closeModalBtn) {
        closeModalBtn.onclick = () => applyModal.style.display = 'none';
    }
    
    window.onclick = (event) => {
        if (event.target == applyModal) applyModal.style.display = 'none';
    };

    // Form Submission
    if (applyForm) {
        applyForm.onsubmit = async (e) => {
            e.preventDefault();
            const jobId = document.getElementById('modal-job-id').value;
            const userStr = localStorage.getItem('user');
            if (!userStr) return;
            
            const user = JSON.parse(userStr);
            const submitBtn = document.getElementById('final-apply-btn');
            const originalBtnText = submitBtn.innerText;
            
            submitBtn.innerText = "Submitting...";
            submitBtn.disabled = true;

            const formData = new FormData();
            formData.append('userId', user.id);
            formData.append('experience_years', document.getElementById('experience').value);
            formData.append('cover_letter', document.getElementById('cover-letter').value);
            formData.append('resume', document.getElementById('resume').files[0]);

            try {
                const response = await fetch(`/api/jobs/${jobId}/apply`, {
                    method: 'POST',
                    body: formData // Fetch handles Content-Type automatically for FormData
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    alert("Application submitted successfully!");
                    applyModal.style.display = 'none';
                    applyForm.reset();
                    // Refresh jobs to show updated state (though we'd need more logic to show 'Applied')
                    window.fetchJobs();
                } else {
                    alert(data.message || "Failed to submit application");
                }
            } catch (err) {
                console.error("Submission Error:", err);
                alert("An error occurred while submitting. Please try again.");
            } finally {
                submitBtn.innerText = originalBtnText;
                submitBtn.disabled = false;
            }
        };
    }

    // Real search functionality
    if (searchBtn) {
        searchBtn.addEventListener('click', () => {
            const term = searchInput.value;
            const activeFilter = document.querySelector('.filter-btn.active');
            const level = activeFilter ? activeFilter.getAttribute('onclick').match(/'([^']+)'/)?.[1] || '' : '';
            
            document.getElementById('job-listings').innerHTML = '<div class="loader" id="loader"></div>';
            window.fetchJobs(level, term);
        });
    }

    if (searchInput) {
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                searchBtn.click();
            }
        });
    }

    // Navigation UI Auth Logic
    const userStr = localStorage.getItem('user');
    if (userStr) {
        if(document.getElementById('nav-login')) document.getElementById('nav-login').style.display = 'none';
        if(document.getElementById('nav-register')) document.getElementById('nav-register').style.display = 'none';
        if(document.getElementById('nav-profile')) document.getElementById('nav-profile').style.display = 'inline';
        if(document.getElementById('logout-btn')) document.getElementById('logout-btn').style.display = 'inline';
    }

    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            localStorage.removeItem('user');
            window.location.reload();
        });
    }
});
