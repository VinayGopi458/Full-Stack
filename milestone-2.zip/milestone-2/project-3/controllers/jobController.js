const db = require('../config/db');

exports.getAllJobs = async (req, res) => {
    try {
        const { level, search } = req.query;
        let query = 'SELECT * FROM jobs WHERE 1=1';
        let params = [];
        
        if (level && ['Entry', 'Mid', 'Advance'].includes(level)) {
            query += ' AND experience_level = ?';
            params.push(level);
        }

        if (search) {
            query += ' AND (title LIKE ? OR company LIKE ? OR description LIKE ?)';
            const searchTerm = `%${search}%`;
            params.push(searchTerm, searchTerm, searchTerm);
        }
        
        query += ' ORDER BY posted_at DESC';
        const [rows] = await db.query(query, params);
        res.json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server Error" });
    }
};

exports.createJob = async (req, res) => {
    try {
        const { title, company, location, salary, description, experience_level, requirements } = req.body;
        const [result] = await db.query(
            'INSERT INTO jobs (title, company, location, salary, experience_level, description, requirements) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [title, company, location, salary, experience_level, description, requirements]
        );
        res.status(201).json({ id: result.insertId, title, company, location });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server Error" });
    }
};

exports.applyToJob = async (req, res) => {
    try {
        const jobId = req.params.id;
        const { userId, experience_years, cover_letter } = req.body;
        const resumeFile = req.file;
        
        if (!userId) {
            return res.status(401).json({ message: "Unauthorized. Must be logged in." });
        }

        if (!resumeFile) {
            return res.status(400).json({ message: "Resume/CV document is required." });
        }
        
        // Ensure user hasn't already applied
        const [existing] = await db.query('SELECT id FROM applications WHERE user_id = ? AND job_id = ?', [userId, jobId]);
        if (existing.length > 0) {
            return res.status(400).json({ message: "You have already applied for this job." });
        }
        
        const resumePath = `/uploads/${resumeFile.filename}`;
        
        await db.query(
            'INSERT INTO applications (user_id, job_id, resume_path, cover_letter, experience_years) VALUES (?, ?, ?, ?, ?)', 
            [userId, jobId, resumePath, cover_letter, experience_years]
        );
        
        res.status(201).json({ 
            message: "Application submitted successfully!",
            resumePath: resumePath
        });
        
    } catch(error) {
        console.error("Application Error:", error);
        res.status(500).json({ message: "Server Error: " + error.message });
    }
};
