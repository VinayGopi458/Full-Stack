const db = require('../config/db');

exports.register = async (req, res) => {
    try {
        const { name, email, password } = req.body;
        
        if (!name || !email || !password) {
            return res.status(400).json({ message: "All fields (name, email, password) are required" });
        }

        const [existingUsers] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
        if (existingUsers.length > 0) {
            return res.status(400).json({ message: "User already exists" });
        }

        const [result] = await db.query(
            'INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
            [name, email, password]
        );
        
        res.status(201).json({ id: result.insertId, name, email, message: "Registration successful" });
    } catch (error) {
        console.error("Registration Exception:", error);
        res.status(500).json({ message: "Server Error" });
    }
};

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        
        const [users] = await db.query('SELECT * FROM users WHERE email = ? AND password = ?', [email, password]);
        
        if (users.length === 0) {
            return res.status(401).json({ message: "Invalid email or password" });
        }
        
        const user = users[0];
        // Returns simple token-less session for local demo
        res.json({ id: user.id, name: user.name, email: user.email, message: "Login successful" });
        
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server Error" });
    }
};

exports.getProfile = async (req, res) => {
    try {
        // Mock authorization: expecting user ID in query or params for simple demo
        const userId = req.params.id;
        const [users] = await db.query('SELECT id, name, email, created_at FROM users WHERE id = ?', [userId]);
        
        if(users.length === 0) {
            return res.status(404).json({ message: "User not found" });
        }
        
        res.json(users[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server Error" });
    }
};

exports.getUserApplications = async (req, res) => {
    try {
        const userId = req.params.id;
        const [applications] = await db.query(`
            SELECT a.id as application_id, a.applied_at, j.* 
            FROM applications a 
            JOIN jobs j ON a.job_id = j.id 
            WHERE a.user_id = ? 
            ORDER BY a.applied_at DESC
        `, [userId]);
        
        res.json(applications);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server Error" });
    }
};
