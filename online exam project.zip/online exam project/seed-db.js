require('dotenv').config();
const fs = require('fs');
const path = require('path');
const db = require('./config/db');

async function seedDatabase() {
    try {
        console.log('Reading schema.sql...');
        const sqlPath = path.join(__dirname, 'schema.sql');
        const sqlParams = fs.readFileSync(sqlPath, 'utf8');

        console.log('Executing SQL script to add all 10 subjects and questions...');
        await db.query(sqlParams);
        
        console.log('✅ Success! The database has been seeded with all 10 subjects and their questions.');
        process.exit(0);
    } catch (error) {
        console.error('❌ Failed to seed database:', error);
        process.exit(1);
    }
}

seedDatabase();
