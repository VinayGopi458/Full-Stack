const db = require('./config/db');
async function test() {
    try {
        const [rows] = await db.execute(
            'SELECT * FROM users WHERE username = ? AND password = ?',
            ['admin', 'admin123']
        );
        console.log("Success:", rows);
    } catch(err) {
        console.error("LOGIN ERROR:", err);
    }
    process.exit();
}
test();
