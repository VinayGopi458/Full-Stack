const fs = require('fs');
const mysql = require('mysql2/promise');
require('dotenv').config();

async function resetDB() {
    try {
        console.log('Connecting to MySQL server...');
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            port: process.env.DB_PORT,
            multipleStatements: true
        });

        console.log('Dropping online12...');
        await connection.query('DROP DATABASE IF EXISTS online12;');
        console.log('Creating online12...');
        await connection.query('CREATE DATABASE online12;');
        await connection.query('USE online12;');

        console.log('Reading schema.sql...');
        const schema = fs.readFileSync('schema.sql', 'utf8');

        console.log('Executing schema...');
        await connection.query(schema);

        console.log('Database online12 reset successfully!');
        await connection.end();
    } catch (err) {
        console.error('Error resetting database:', err);
    }
}

resetDB();
