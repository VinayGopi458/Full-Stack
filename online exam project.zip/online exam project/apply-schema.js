const db = require('./config/db');
const dotenv = require('dotenv');
dotenv.config();

async function updateSchema() {
    try {
        console.log('Updating schema...');

        // Reset Results table structure
        await db.execute('DROP TABLE IF EXISTS results');
        await db.execute(`
            CREATE TABLE results (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                score INT NOT NULL,
                total_questions INT NOT NULL,
                percentage DECIMAL(5, 2),
                exam_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        `);
        console.log('Results table verified.');

        // Reset Questions
        await db.execute('TRUNCATE TABLE questions');
        const questions = [
            ['What does HTML stand for?', 'Hyper Text Preprocessor', 'Hyper Text Markup Language', 'Hyper Text Multiple Language', 'Hyper Tool Multi Language', 'B', 'Web Tech'],
            ['What does CSS stand for?', 'Common Style Sheet', 'Colorful Style Sheet', 'Computer Style Sheet', 'Cascading Style Sheet', 'D', 'Web Tech'],
            ['Which language is used for web logic?', 'PHP', 'Python', 'JavaScript', 'C++', 'C', 'Web Tech'],
            ['What is the default port for MySQL?', '3306', '8080', '27017', '5432', 'A', 'Database'],
            ['Which tag is used for the largest heading in HTML?', '<h6>', '<head>', '<h1>', '<header>', 'C', 'Web Tech'],
            ['Which CSS property is used to change text color?', 'font-color', 'text-color', 'color', 'background-color', 'C', 'CSS'],
            ['Which CSS property controls the space inside an element?', 'margin', 'padding', 'border', 'spacing', 'B', 'CSS'],
            ['Which symbol is used for comments in JavaScript?', '//', '/* */', '#', '<!-- -->', 'A', 'JavaScript'],
            ['Which keyword is used to declare a constant in JavaScript?', 'var', 'let', 'const', 'static', 'C', 'JavaScript'],
            ['Which method is used to print output in JavaScript console?', 'print()', 'console.log()', 'log()', 'echo()', 'B', 'JavaScript'],
            ['Which SQL command is used to retrieve data from a table?', 'GET', 'FETCH', 'SELECT', 'SHOW', 'C', 'SQL'],
            ['Which SQL clause is used to filter records?', 'WHERE', 'ORDER BY', 'GROUP BY', 'HAVING', 'A', 'SQL'],
            ['Which SQL statement is used to remove a table?', 'DELETE', 'DROP', 'REMOVE', 'TRUNCATE', 'B', 'SQL'],
            ['Which CSS property is used to make elements flexible in layout?', 'float', 'display', 'position', 'flex', 'D', 'CSS'],
            ['Which JavaScript function converts a string to integer?', 'parseInt()', 'Number()', 'toInt()', 'Integer()', 'A', 'JavaScript']
        ];

        for (const q of questions) {
            await db.execute(
                'INSERT INTO questions (question_text, option_a, option_b, option_c, option_d, correct_option, subject) VALUES (?, ?, ?, ?, ?, ?, ?)',
                q
            );
        }
        console.log('Questions reset to the requested set.');

        console.log('Schema update complete.');
        process.exit(0);
    } catch (err) {
        console.error('Error updating schema:', err);
        process.exit(1);
    }
}

updateSchema();
