const fs = require('fs');
let content = fs.readFileSync('schema.sql', 'utf8');
content = content.replace(/\\n/g, '\n');
fs.writeFileSync('schema.sql', content);
console.log('Fixed literal newlines in schema.sql');
