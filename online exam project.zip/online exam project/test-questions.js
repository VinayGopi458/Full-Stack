const db = require('./config/db');

async function test() {
    try {
        const [rows] = await db.query('SELECT subject, COUNT(id) as count FROM questions GROUP BY subject');
        console.log("Subjects and question counts:");
        rows.forEach(r => console.log(`- ${r.subject}: ${r.count}`));
        process.exit(0);
    } catch(err) {
        console.error(err);
        process.exit(1);
    }
}
test();
