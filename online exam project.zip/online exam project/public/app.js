const app = {
    user: null,
    questions: [],
    currentQIndex: 0,
    answers: {},
    timeLeft: 0,
    timerInterval: null,

    toggleAuth() {
        document.getElementById('login-form').classList.toggle('hidden');
        document.getElementById('register-form').classList.toggle('hidden');
    },

    async login() {
        const username = document.getElementById('login-username').value;
        const password = document.getElementById('login-password').value;
        const res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (data.success) {
            this.user = data.user;
            this.showDashboard();
        } else {
            alert(data.message);
        }
    },

    async register() {
        const username = document.getElementById('reg-username').value;
        const password = document.getElementById('reg-password').value;
        const res = await fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (data.success) {
            alert('Registration successful! Please login.');
            this.toggleAuth();
        } else {
            alert(data.message);
        }
    },

    showDashboard() {
        this.hideAll();
        if (this.user.role === 'admin') {
            document.getElementById('admin-section').classList.remove('hidden');
            this.loadAdminResults();
        } else {
            document.getElementById('student-dashboard').classList.remove('hidden');
            document.getElementById('welcome-msg').innerText = `Hello, ${this.user.username}! Ready for your exam?`;
            this.loadSubjects();
        }
    },

    async loadSubjects() {
        const res = await fetch('/api/subjects');
        const subjects = await res.json();
        this.renderSubjects(subjects);
    },

    renderSubjects(subjects) {
        const container = document.getElementById('subjects-container');
        container.innerHTML = '';

        const icons = {
            'JavaScript': 'fa-brands fa-js',
            'Java': 'fa-brands fa-java',
            'HTML': 'fa-brands fa-html5',
            'CSS': 'fa-brands fa-css3-alt',
            'Python': 'fa-brands fa-python',
            'SQL': 'fa-solid fa-database',
            'C Language': 'fa-solid fa-c',
            'C++': 'fa-brands fa-cuttlefish',
            'Logical Aptitude': 'fa-solid fa-brain',
            'Vocabulary': 'fa-solid fa-book',
            'Web Tech': 'fa-solid fa-code',
            'Database': 'fa-solid fa-database'
        };

        subjects.forEach(subject => {
            const card = document.createElement('div');
            card.className = 'subject-card';
            card.onclick = () => this.startExam(subject);

            const iconClass = icons[subject] || 'fa-solid fa-file-lines';
            card.innerHTML = `
                <i class="${iconClass}"></i>
                <span>${subject}</span>
            `;
            container.appendChild(card);
        });
    },

    async startExam(subject) {
        console.log(`Starting exam for subject: ${subject}...`);
        this.currentSubject = subject || 'General';
        const url = subject ? `/api/questions?subject=${encodeURIComponent(subject)}` : '/api/questions';
        const res = await fetch(url);
        const data = await res.json();
        console.log('API Response:', data);

        if (!data.questions || data.questions.length === 0) {
            alert('No questions found. Please contact admin.');
            this.showDashboard();
            return;
        }

        this.questions = data.questions;
        this.timeLeft = (parseInt(data.duration) || 10) * 60; // Convert to seconds

        this.currentQIndex = 0;
        this.answers = {};
        this.hideAll();
        document.getElementById('exam-section').classList.remove('hidden');
        this.renderQuestion();
        this.startTimer();
    },

    startTimer() {
        if (this.timerInterval) clearInterval(this.timerInterval);
        console.log('Timer started with:', this.timeLeft);

        const updateDisplay = () => {
            const mins = Math.floor(this.timeLeft / 60);
            const secs = Math.floor(this.timeLeft % 60);
            const display = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
            document.getElementById('timer').innerText = `Time Left: ${display}`;
        };

        updateDisplay();
        this.timerInterval = setInterval(() => {
            this.timeLeft--;
            updateDisplay();
            if (this.timeLeft <= 0) {
                clearInterval(this.timerInterval);
                alert('Time is up! Submitting your exam...');
                this.submitExam();
            }
        }, 1000);
    },

    renderQuestion() {
        if (!this.questions || this.questions.length === 0) return;
        const q = this.questions[this.currentQIndex];
        if (!q) return;

        // Update Question Counter
        document.getElementById('question-counter').innerText = `Question ${this.currentQIndex + 1} of ${this.questions.length}`;

        document.getElementById('q-text').innerText = `${this.currentQIndex + 1}. ${q.question_text}`;

        const container = document.getElementById('options-container');
        container.innerHTML = '';

        ['A', 'B', 'C', 'D'].forEach(opt => {
            const btn = document.createElement('button');
            const optKey = `option_${opt.toLowerCase()}`;
            btn.className = 'option-btn';
            if (this.answers[q.id] === opt) btn.classList.add('selected');
            btn.innerText = `${opt}: ${q[optKey]}`;
            btn.onclick = () => {
                this.answers[q.id] = opt;
                Array.from(container.children).forEach(c => c.classList.remove('selected'));
                btn.classList.add('selected');
            };
            container.appendChild(btn);
        });

        const progress = ((this.currentQIndex + 1) / this.questions.length) * 100;
        document.getElementById('progress').style.width = `${progress}%`;

        const nextBtn = document.getElementById('next-btn');
        nextBtn.innerText = this.currentQIndex === this.questions.length - 1 ? 'Submit Exam' : 'Next Question';
    },

    nextQuestion() {
        if (!this.answers[this.questions[this.currentQIndex].id]) {
            alert('Please select an option');
            return;
        }

        if (this.currentQIndex < this.questions.length - 1) {
            this.currentQIndex++;
            this.renderQuestion();
        } else {
            this.submitExam();
        }
    },

    async submitExam() {
        if (this.timerInterval) clearInterval(this.timerInterval);
        const res = await fetch('/api/submit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId: this.user.id, subject: this.currentSubject, answers: this.answers })
        });
        const data = await res.json();
        if (data.success) {
            this.showResult(data);
        }
    },

    showResult(data) {
        this.hideAll();
        document.getElementById('result-section').classList.remove('hidden');
        document.getElementById('score-circle').innerText = `${Math.round(data.percentage)}%`;

        const answeredCount = Object.keys(this.answers).length;
        document.getElementById('answered-count').innerText = `Questions Answered: ${answeredCount}/${this.questions.length}`;

        document.getElementById('score-text').innerText = `You scored ${data.score} out of ${data.total}`;

        const status = data.status || (data.percentage >= 50 ? 'Pass' : 'Fail');
        console.log('Result Data:', data, 'Calculated Status:', status);

        const statusEl = document.getElementById('result-status');
        if (statusEl) {
            statusEl.innerText = status;
            statusEl.className = `status-text ${status === 'Pass' ? 'status-pass-text' : 'status-fail-text'}`;
        }
        
        this.loadLeaderboard();
    },

    async loadAdminResults() {
        const res = await fetch('/api/admin/results');
        const data = await res.json();
        const body = document.getElementById('results-body');
        body.innerHTML = '';
        data.forEach(r => {
            const status = r.percentage >= 50 ? 'Pass' : 'Fail';
            const statusClass = status === 'Pass' ? 'status-pass' : 'status-fail';
            const row = `<tr>
                <td>${r.username}</td>
                <td>${r.subject || 'General'}</td>
                <td>${r.score}</td>
                <td>${r.total_questions}</td>
                <td>${r.percentage}%</td>
                <td><span class="status-badge ${statusClass}">${status}</span></td>
                <td>${new Date(r.exam_date).toLocaleDateString()}</td>
            </tr>`;
            body.innerHTML += row;
        });
    },

    async showProfile() {
        this.hideAll();
        const profileSec = document.getElementById('profile-section');
        if(profileSec) profileSec.classList.remove('hidden');
        const userEl = document.getElementById('profile-username');
        if(userEl) userEl.innerText = this.user.username;
        this.loadProfileResults();
    },

    async loadProfileResults() {
        const res = await fetch(`/api/user/results?userId=${this.user.id}`);
        const data = await res.json();
        const body = document.getElementById('profile-results-body');
        if(!body) return;
        body.innerHTML = '';
        data.forEach(r => {
            const status = r.percentage >= 50 ? 'Pass' : 'Fail';
            const statusClass = status === 'Pass' ? 'status-pass' : 'status-fail';
            body.innerHTML += `<tr>
                <td>${r.subject || 'General'}</td>
                <td>${r.score}/${r.total_questions}</td>
                <td>${r.percentage}%</td>
                <td><span class="status-badge ${statusClass}">${status}</span></td>
                <td>${new Date(r.exam_date).toLocaleDateString()}</td>
            </tr>`;
        });
    },

    async loadLeaderboard() {
        const res = await fetch('/api/leaderboard');
        const data = await res.json();
        const container = document.getElementById('leaderboard-list');
        if (!container) return;
        container.innerHTML = '';
        data.forEach((r, i) => {
            const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i+1}.`;
            container.innerHTML += `<div class="leaderboard-item">
                <span class="rank">${medal}</span>
                <span class="user">${r.username}</span>
                <span class="score">${r.percentage}%</span>
            </div>`;
        });
    },

    logout() {
        this.user = null;
        this.hideAll();
        document.getElementById('auth-section').classList.remove('hidden');
    },

    hideAll() {
        ['auth-section', 'student-dashboard', 'exam-section', 'result-section', 'admin-section', 'profile-section'].forEach(id => {
            const el = document.getElementById(id);
            if(el) el.classList.add('hidden');
        });
    }
};
