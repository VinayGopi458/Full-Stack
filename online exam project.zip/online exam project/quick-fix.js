const db = require('./config/db');

async function fix() {
    try {
        console.log("Updating exam duration to 20 in the database...");
        await db.execute("UPDATE settings SET setting_value = '20' WHERE setting_key = 'exam_duration'");
        
        console.log("Cleaning up duplicate questions to ensure exactly 20 per subject in the database...");
        
        // This query keeps the first 20 IDs for each subject and deletes the rest
        await db.execute(`
            DELETE FROM questions 
            WHERE id NOT IN (
                SELECT id FROM (
                    SELECT id, 
                           ROW_NUMBER() OVER(PARTITION BY subject ORDER BY id) as row_num 
                    FROM questions
                ) t 
                WHERE row_num <= 20
            )
        `);
        
        console.log("✅ Fixed! Time is now 20 minutes, and duplicates removed.");
        process.exit(0);
    } catch(e) {
        console.error(e);
        process.exit(1);
    }
}
fix();
