require('dotenv').config();
const express = require('express');
const path = require('path');
const db = require('./config/db');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const publicPath = path.join(__dirname, 'public');
console.log('Serving static files from:', publicPath);
app.use(express.static(publicPath));

// Explicit route for home page
app.get('/', (req, res) => {
    res.sendFile(path.join(publicPath, 'index.html'));
});

// API Routes
app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const [rows] = await db.execute(
            'SELECT * FROM users WHERE username = ? AND password = ?',
            [username, password]
        );

        if (rows.length > 0) {
            res.json({ success: true, user: rows[0] });
        } else {
            res.status(401).json({ success: false, message: 'Invalid credentials' });
        }
    } catch (err) {
        console.error("LOGIN ERROR:", err);  // 👈 important
        res.status(500).json({ success: false, message: 'Database error' });
    }
});

app.post('/api/auth/register', async (req, res) => {
    const { username, password, role } = req.body;
    try {
        await db.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', [username, password, role || 'student']);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Username might already exist' });
    }
});

app.get('/api/questions', async (req, res) => {
    const { subject } = req.query;
    try {
        let query = 'SELECT id, question_text, option_a, option_b, option_c, option_d FROM questions';
        let params = [];
        if (subject) {
            query += ' WHERE subject = ?';
            params.push(subject);
        }
        query += ' ORDER BY RAND() LIMIT 20';
        const [questions] = await db.execute(query, params);
        const [settings] = await db.execute('SELECT setting_value FROM settings WHERE setting_key = "exam_duration"');

        const duration = settings.length > 0 ? parseInt(settings[0].setting_value) : 10; // Default 10 mins

        res.json({
            questions,
            duration
        });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Database error' });
    }
});

app.get('/api/subjects', async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT DISTINCT subject FROM questions');
        const subjects = rows.map(r => r.subject).filter(s => s); // Remove nulls
        res.json(subjects);
    } catch (err) {
        res.status(500).json({ success: false, message: 'Database error' });
    }
});

app.post('/api/submit', async (req, res) => {
    const { userId, subject, answers } = req.body; // answers = { qId: 'A', ... }
    try {
        const questionIds = Object.keys(answers);
        if (questionIds.length === 0) {
            return res.status(400).json({ success: false, message: 'No answers provided' });
        }
        const placeholders = questionIds.map(() => '?').join(',');
        const [questions] = await db.execute(`SELECT id, correct_option FROM questions WHERE id IN (${placeholders})`, questionIds);
        
        let score = 0;
        questions.forEach(q => {
            if (answers[q.id] === q.correct_option) {
                score++;
            }
        });
        const total = questions.length;
        const percentage = total > 0 ? (score / total) * 100 : 0;
        const status = percentage >= 50 ? 'Pass' : 'Fail';

        await db.execute('INSERT INTO results (user_id, subject, score, total_questions, percentage) VALUES (?, ?, ?, ?, ?)',
            [userId, subject || 'General', score, total, percentage]);

        res.json({ success: true, score, total, percentage, status });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Submission error' });
    }
});

app.get('/api/admin/results', async (req, res) => {
    try {
        const [rows] = await db.execute(`
            SELECT results.*, users.username 
            FROM results 
            JOIN users ON results.user_id = users.id 
            ORDER BY exam_date DESC
        `);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ success: false, message: 'Database error' });
    }
});

app.get('/api/user/results', async (req, res) => {
    const { userId } = req.query;
    try {
        const [rows] = await db.execute(`
            SELECT * FROM results 
            WHERE user_id = ? 
            ORDER BY exam_date DESC
        `, [userId]);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ success: false, message: 'Database error' });
    }
});

app.get('/api/leaderboard', async (req, res) => {
    try {
        const [rows] = await db.execute(`
            SELECT r.score, r.percentage, u.username, r.exam_date 
            FROM results r
            JOIN users u ON r.user_id = u.id
            ORDER BY r.percentage DESC, r.score DESC, r.exam_date DESC
            LIMIT 10
        `);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ success: false, message: 'Database error' });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
