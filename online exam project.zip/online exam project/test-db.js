const db = require('./config/db');

async function testConnection() {
    try {
        console.log('Testing connection to database: onlineExam1...');
        const [rows] = await db.execute('SELECT 1 + 1 AS result');
        console.log('✅ Database connection successful!');

        const [tables] = await db.execute('SHOW TABLES');
        console.log('Tables found:', tables.map(t => Object.values(t)[0]).join(', '));

        if (tables.length === 0) {
            console.log('⚠️ Warning: No tables found. Did you run schema.sql?');
        }
    } catch (err) {
        console.error('❌ Database connection failed!');
        console.error(err.message);
        console.log('\nTip: Make sure MySQL is running and you have run the schema.sql script.');
    } finally {
        process.exit();
    }
}

testConnection();
