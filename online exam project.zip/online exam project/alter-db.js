const db = require('./config/db');
async function alter() {
    try {
        await db.execute("ALTER TABLE results ADD COLUMN subject VARCHAR(50) DEFAULT 'General'");
        console.log("Added subject column to results table.");
        process.exit(0);
    } catch(err) {
        // Ignore if exists
        console.log("Column might already exist", err.message);
        process.exit(0);
    }
}
alter();
